import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kids-page',
  templateUrl: './kids-page.component.html',
  styleUrls: ['./kids-page.component.scss']
})
export class KidsPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
