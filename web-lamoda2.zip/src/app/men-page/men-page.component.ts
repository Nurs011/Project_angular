import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-men-page',
  templateUrl: './men-page.component.html',
  styleUrls: ['./men-page.component.scss']
})
export class MenPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
