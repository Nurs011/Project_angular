import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-women-page',
  templateUrl: './women-page.component.html',
  styleUrls: ['./women-page.component.scss']
})
export class WomenPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
